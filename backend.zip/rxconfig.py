import reflex as rx

config = rx.Config(
    app_name="hola",
    db_url="postgresql://postgres:V32273930@localhost:5432/mi_pagina",
    plugins=[
        rx.plugins.SitemapPlugin(),
        rx.plugins.TailwindV4Plugin(),
    ]

)
